x = 1.0;
while x < 1000
	x = x*2;
	disp(x);
endwhile