function [s] = suma(a,b)
	s = a + b;
endfunction