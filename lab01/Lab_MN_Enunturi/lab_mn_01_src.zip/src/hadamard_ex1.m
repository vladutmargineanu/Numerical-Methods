for i = 1 : n
    for j = 1 : n
        M(i,j) = A(i,j)/(B(i,j)*C(i,j));
    end
end