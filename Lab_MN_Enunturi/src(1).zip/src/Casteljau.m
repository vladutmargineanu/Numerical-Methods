function P = Casteljau(x, y, t)
	
	n = length(x);
	
	plot(x, y, 'k-o');
	legend ('puncte de control');
	hold on;
	axis([0.5, 4.5, 0.2, 2.1]);

  TODO	
endfunction