function yi = SplineC2natural(x, y, xi)
