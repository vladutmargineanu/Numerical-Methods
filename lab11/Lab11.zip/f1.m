function y = f1(x)
  y = log2(x * x + 1);
  endfunction